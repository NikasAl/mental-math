import 'package:json_annotation/json_annotation.dart';

part 'billing.g.dart';

@JsonSerializable()
class BillingBalanceModel {
  final double balance;
  final String currency;
  final int freeUsesLeft;
  final int totalDailyLimit;

  BillingBalanceModel({
    required this.balance,
    required this.currency,
    required this.freeUsesLeft,
    required this.totalDailyLimit,
  });

  factory BillingBalanceModel.fromJson(Map<String, dynamic> json) =>
      _$BillingBalanceModelFromJson(json);

  Map<String, dynamic> toJson() => _$BillingBalanceModelToJson(this);

  double get freeUsesProgress => freeUsesLeft / totalDailyLimit;

  bool get hasFreeUses => freeUsesLeft > 0;

  bool get hasBalance => balance > 0;
}

@JsonSerializable()
class TopUpResponse {
  final String paymentUrl;
  final String? paymentId;

  TopUpResponse({
    required this.paymentUrl,
    this.paymentId,
  });

  factory TopUpResponse.fromJson(Map<String, dynamic> json) =>
      _$TopUpResponseFromJson(json);

  Map<String, dynamic> toJson() => _$TopUpResponseToJson(this);
}
