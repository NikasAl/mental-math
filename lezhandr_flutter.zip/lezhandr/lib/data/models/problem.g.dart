// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'problem.dart';

SourceModel _$SourceModelFromJson(Map<String, dynamic> json) => SourceModel(
      id: json['id'] as int,
      name: json['name'] as String,
      slug: json['slug'] as String,
      urlTemplate: json['url_template'] as String?,
    );

Map<String, dynamic> _$SourceModelToJson(SourceModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'slug': instance.slug,
      'url_template': instance.urlTemplate,
    };

TagModel _$TagModelFromJson(Map<String, dynamic> json) => TagModel(
      id: json['id'] as int,
      name: json['name'] as String,
      slug: json['slug'] as String,
    );

Map<String, dynamic> _$TagModelToJson(TagModel instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'slug': instance.slug,
    };

ProblemModel _$ProblemModelFromJson(Map<String, dynamic> json) => ProblemModel(
      id: json['id'] as int,
      sourceId: json['source_id'] as int,
      reference: json['reference'] as String,
      conditionText: json['condition_text'] as String?,
      conditionImg: json['condition_img'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      source: SourceModel.fromJson(json['source'] as Map<String, dynamic>),
      tags: (json['tags'] as List<dynamic>)
          .map((e) => TagModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      concepts: (json['concepts'] as List<dynamic>?)
          ?.map((e) =>
              ProblemConceptModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ProblemModelToJson(ProblemModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'source_id': instance.sourceId,
      'reference': instance.reference,
      'condition_text': instance.conditionText,
      'condition_img': instance.conditionImg,
      'created_at': instance.createdAt.toIso8601String(),
      'source': instance.source.toJson(),
      'tags': instance.tags.map((e) => e.toJson()).toList(),
      'concepts': instance.concepts?.map((e) => e.toJson()).toList(),
    };

ProblemCreate _$ProblemCreateFromJson(Map<String, dynamic> json) =>
    ProblemCreate(
      reference: json['reference'] as String,
      sourceName: json['source_name'] as String,
      tags: (json['tags'] as List<dynamic>).map((e) => e as String).toList(),
      conditionText: json['condition_text'] as String?,
    );

Map<String, dynamic> _$ProblemCreateToJson(ProblemCreate instance) =>
    <String, dynamic>{
      'reference': instance.reference,
      'source_name': instance.sourceName,
      'tags': instance.tags,
      'condition_text': instance.conditionText,
    };

ProblemUpdate _$ProblemUpdateFromJson(Map<String, dynamic> json) =>
    ProblemUpdate(
      conditionText: json['condition_text'] as String?,
      reference: json['reference'] as String?,
      tags: (json['tags'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$ProblemUpdateToJson(ProblemUpdate instance) =>
    <String, dynamic>{
      'condition_text': instance.conditionText,
      'reference': instance.reference,
      'tags': instance.tags,
    };

ProblemConceptModel _$ProblemConceptModelFromJson(Map<String, dynamic> json) =>
    ProblemConceptModel(
      problemId: json['problem_id'] as int,
      conceptId: json['concept_id'] as int,
      relevance: (json['relevance'] as num).toDouble(),
      explanation: json['explanation'] as String?,
      concept: ConceptModel.fromJson(json['concept'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ProblemConceptModelToJson(ProblemConceptModel instance) =>
    <String, dynamic>{
      'problem_id': instance.problemId,
      'concept_id': instance.conceptId,
      'relevance': instance.relevance,
      'explanation': instance.explanation,
      'concept': instance.concept.toJson(),
    };

ConceptModel _$ConceptModelFromJson(Map<String, dynamic> json) => ConceptModel(
      id: json['id'] as int,
      name: json['name'] as String,
      slug: json['slug'] as String,
      description: json['description'] as String?,
      utilityDescription: json['utility_description'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
    );

Map<String, dynamic> _$ConceptModelToJson(ConceptModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'slug': instance.slug,
      'description': instance.description,
      'utility_description': instance.utilityDescription,
      'created_at': instance.createdAt.toIso8601String(),
    };
