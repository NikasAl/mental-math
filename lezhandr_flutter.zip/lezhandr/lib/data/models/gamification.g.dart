// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gamification.dart';

GamificationModel _$GamificationModelFromJson(Map<String, dynamic> json) =>
    GamificationModel(
      userId: json['user_id'] as int,
      totalXp: (json['total_xp'] as num).toDouble(),
      currentLevel: json['current_level'] as int,
      currentHearts: json['current_hearts'] as int,
      maxHearts: json['max_hearts'] as int,
      streakCurrent: json['streak_current'] as int,
      streakMax: json['streak_max'] as int,
      solvedTasksToday: json['solved_tasks_today'] as int,
      lastActivityDate: json['last_activity_date'] == null
          ? null
          : DateTime.parse(json['last_activity_date'] as String),
    );

Map<String, dynamic> _$GamificationModelToJson(GamificationModel instance) =>
    <String, dynamic>{
      'user_id': instance.userId,
      'total_xp': instance.totalXp,
      'current_level': instance.currentLevel,
      'current_hearts': instance.currentHearts,
      'max_hearts': instance.maxHearts,
      'streak_current': instance.streakCurrent,
      'streak_max': instance.streakMax,
      'solved_tasks_today': instance.solvedTasksToday,
      'last_activity_date': instance.lastActivityDate?.toIso8601String(),
    };

DailyActivityModel _$DailyActivityModelFromJson(Map<String, dynamic> json) =>
    DailyActivityModel(
      date: json['date'] as String,
      xp: (json['xp'] as num).toDouble(),
      timeMinutes: (json['time_minutes'] as num).toDouble(),
      tasksCount: json['tasks_count'] as int,
    );

Map<String, dynamic> _$DailyActivityModelToJson(DailyActivityModel instance) =>
    <String, dynamic>{
      'date': instance.date,
      'xp': instance.xp,
      'time_minutes': instance.timeMinutes,
      'tasks_count': instance.tasksCount,
    };

ActivityResponse _$ActivityResponseFromJson(Map<String, dynamic> json) =>
    ActivityResponse(
      items: (json['items'] as List<dynamic>)
          .map((e) => DailyActivityModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalXp: (json['total_xp'] as num).toDouble(),
      totalTimeMinutes: (json['total_time_minutes'] as num).toDouble(),
      totalTasks: json['total_tasks'] as int,
    );

Map<String, dynamic> _$ActivityResponseToJson(ActivityResponse instance) =>
    <String, dynamic>{
      'items': instance.items.map((e) => e.toJson()).toList(),
      'total_xp': instance.totalXp,
      'total_time_minutes': instance.totalTimeMinutes,
      'total_tasks': instance.totalTasks,
    };
