import 'package:json_annotation/json_annotation.dart';

part 'problem.g.dart';

@JsonSerializable()
class SourceModel {
  final int id;
  final String name;
  final String slug;
  final String? urlTemplate;

  SourceModel({
    required this.id,
    required this.name,
    required this.slug,
    this.urlTemplate,
  });

  factory SourceModel.fromJson(Map<String, dynamic> json) =>
      _$SourceModelFromJson(json);

  Map<String, dynamic> toJson() => _$SourceModelToJson(this);
}

@JsonSerializable()
class TagModel {
  final int id;
  final String name;
  final String slug;

  TagModel({
    required this.id,
    required this.name,
    required this.slug,
  });

  factory TagModel.fromJson(Map<String, dynamic> json) =>
      _$TagModelFromJson(json);

  Map<String, dynamic> toJson() => _$TagModelToJson(this);
}

@JsonSerializable()
class ProblemModel {
  final int id;
  final int sourceId;
  final String reference;
  final String? conditionText;
  final String? conditionImg;
  final DateTime createdAt;
  final SourceModel source;
  final List<TagModel> tags;
  final List<ProblemConceptModel>? concepts;

  ProblemModel({
    required this.id,
    required this.sourceId,
    required this.reference,
    this.conditionText,
    this.conditionImg,
    required this.createdAt,
    required this.source,
    required this.tags,
    this.concepts,
  });

  factory ProblemModel.fromJson(Map<String, dynamic> json) =>
      _$ProblemModelFromJson(json);

  Map<String, dynamic> toJson() => _$ProblemModelToJson(this);

  bool get hasText => conditionText != null && conditionText!.isNotEmpty;

  bool get hasImage => conditionImg != null && conditionImg!.isNotEmpty;

  String get displayTitle => '${source.name} - $reference';
}

@JsonSerializable()
class ProblemCreate {
  final String reference;
  final String sourceName;
  final List<String> tags;
  final String? conditionText;

  ProblemCreate({
    required this.reference,
    required this.sourceName,
    required this.tags,
    this.conditionText,
  });

  Map<String, dynamic> toJson() => _$ProblemCreateToJson(this);
}

@JsonSerializable()
class ProblemUpdate {
  final String? conditionText;
  final String? reference;
  final List<String>? tags;

  ProblemUpdate({
    this.conditionText,
    this.reference,
    this.tags,
  });

  Map<String, dynamic> toJson() => _$ProblemUpdateToJson(this);
}

@JsonSerializable()
class ProblemConceptModel {
  final int problemId;
  final int conceptId;
  final double relevance;
  final String? explanation;
  final ConceptModel concept;

  ProblemConceptModel({
    required this.problemId,
    required this.conceptId,
    required this.relevance,
    this.explanation,
    required this.concept,
  });

  factory ProblemConceptModel.fromJson(Map<String, dynamic> json) =>
      _$ProblemConceptModelFromJson(json);

  Map<String, dynamic> toJson() => _$ProblemConceptModelToJson(this);
}

@JsonSerializable()
class ConceptModel {
  final int id;
  final String name;
  final String slug;
  final String? description;
  final String? utilityDescription;
  final DateTime createdAt;

  ConceptModel({
    required this.id,
    required this.name,
    required this.slug,
    this.description,
    this.utilityDescription,
    required this.createdAt,
  });

  factory ConceptModel.fromJson(Map<String, dynamic> json) =>
      _$ConceptModelFromJson(json);

  Map<String, dynamic> toJson() => _$ConceptModelToJson(this);
}
