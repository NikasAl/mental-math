import 'package:json_annotation/json_annotation.dart';

part 'user.g.dart';

enum UserRole { admin, moderator, user }

@JsonSerializable()
class UserModel {
  final int id;
  final String? email;
  final String username;
  final bool isAnonymous;
  final String? deviceId;
  final UserRole role;
  final DateTime createdAt;

  UserModel({
    required this.id,
    this.email,
    required this.username,
    required this.isAnonymous,
    this.deviceId,
    required this.role,
    required this.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);

  Map<String, dynamic> toJson() => _$UserModelToJson(this);

  String get displayName => username;

  bool get isAdmin => role == UserRole.admin;

  bool get isModerator => role == UserRole.moderator || isAdmin;
}

@JsonSerializable()
class AuthResponse {
  final String accessToken;
  final String tokenType;
  final UserModel? user;

  AuthResponse({
    required this.accessToken,
    required this.tokenType,
    this.user,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) =>
      _$AuthResponseFromJson(json);

  Map<String, dynamic> toJson() => _$AuthResponseToJson(this);
}

@JsonSerializable()
class DeviceLoginRequest {
  final String deviceId;
  final String secretKey;

  DeviceLoginRequest({
    required this.deviceId,
    required this.secretKey,
  });

  Map<String, dynamic> toJson() => _$DeviceLoginRequestToJson(this);
}

@JsonSerializable()
class ConvertAccountRequest {
  final String email;
  final String password;
  final String? username;

  ConvertAccountRequest({
    required this.email,
    required this.password,
    this.username,
  });

  Map<String, dynamic> toJson() => _$ConvertAccountRequestToJson(this);
}
