import 'package:json_annotation/json_annotation.dart';

part 'gamification.g.dart';

@JsonSerializable()
class GamificationModel {
  final int userId;
  final double totalXp;
  final int currentLevel;
  final int currentHearts;
  final int maxHearts;
  final int streakCurrent;
  final int streakMax;
  final int solvedTasksToday;
  final DateTime? lastActivityDate;

  GamificationModel({
    required this.userId,
    required this.totalXp,
    required this.currentLevel,
    required this.currentHearts,
    required this.maxHearts,
    required this.streakCurrent,
    required this.streakMax,
    required this.solvedTasksToday,
    this.lastActivityDate,
  });

  factory GamificationModel.fromJson(Map<String, dynamic> json) =>
      _$GamificationModelFromJson(json);

  Map<String, dynamic> toJson() => _$GamificationModelToJson(this);

  double get xpProgress {
    // XP needed for next level
    final xpForCurrentLevel = currentLevel * 100;
    final xpForNextLevel = (currentLevel + 1) * 100;
    final xpInLevel = totalXp - xpForCurrentLevel;
    final xpNeeded = xpForNextLevel - xpForCurrentLevel;
    return xpInLevel / xpNeeded;
  }

  double get heartsProgress => currentHearts / maxHearts;

  bool get streakAtRisk => streakCurrent > 0 && solvedTasksToday == 0;
}

@JsonSerializable()
class DailyActivityModel {
  final String date;
  final double xp;
  final double timeMinutes;
  final int tasksCount;

  DailyActivityModel({
    required this.date,
    required this.xp,
    required this.timeMinutes,
    required this.tasksCount,
  });

  factory DailyActivityModel.fromJson(Map<String, dynamic> json) =>
      _$DailyActivityModelFromJson(json);

  Map<String, dynamic> toJson() => _$DailyActivityModelToJson(this);
}

@JsonSerializable()
class ActivityResponse {
  final List<DailyActivityModel> items;
  final double totalXp;
  final double totalTimeMinutes;
  final int totalTasks;

  ActivityResponse({
    required this.items,
    required this.totalXp,
    required this.totalTimeMinutes,
    required this.totalTasks,
  });

  factory ActivityResponse.fromJson(Map<String, dynamic> json) =>
      _$ActivityResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ActivityResponseToJson(this);
}
