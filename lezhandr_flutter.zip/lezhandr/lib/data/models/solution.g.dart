// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'solution.dart';

const _$SolutionStatusEnumMap = {
  SolutionStatus.active: 'active',
  SolutionStatus.completed: 'completed',
  SolutionStatus.abandoned: 'abandoned',
};

SolutionModel _$SolutionModelFromJson(Map<String, dynamic> json) =>
    SolutionModel(
      id: json['id'] as int,
      problemId: json['problem_id'] as int,
      userId: json['user_id'] as int,
      status: $enumDecode(_$SolutionStatusEnumMap, json['status']),
      personalDifficulty: json['personal_difficulty'] as int?,
      qualityScore: (json['quality_score'] as num?)?.toDouble(),
      xpEarned: (json['xp_earned'] as num?)?.toDouble(),
      userNotes: json['user_notes'] as String?,
      solutionImgPath: json['solution_img_path'] as String?,
      solutionText: json['solution_text'] as String?,
      totalMinutes: (json['total_minutes'] as num).toDouble(),
      createdAt: DateTime.parse(json['created_at'] as String),
      problem: json['problem'] == null
          ? null
          : ProblemModel.fromJson(json['problem'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$SolutionModelToJson(SolutionModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'problem_id': instance.problemId,
      'user_id': instance.userId,
      'status': _$SolutionStatusEnumMap[instance.status],
      'personal_difficulty': instance.personalDifficulty,
      'quality_score': instance.qualityScore,
      'xp_earned': instance.xpEarned,
      'user_notes': instance.userNotes,
      'solution_img_path': instance.solutionImgPath,
      'solution_text': instance.solutionText,
      'total_minutes': instance.totalMinutes,
      'created_at': instance.createdAt.toIso8601String(),
      'problem': instance.problem?.toJson(),
    };

SolutionCreate _$SolutionCreateFromJson(Map<String, dynamic> json) =>
    SolutionCreate(
      problemId: json['problem_id'] as int,
    );

Map<String, dynamic> _$SolutionCreateToJson(SolutionCreate instance) =>
    <String, dynamic>{
      'problem_id': instance.problemId,
    };

SolutionFinish _$SolutionFinishFromJson(Map<String, dynamic> json) =>
    SolutionFinish(
      status: json['status'] as String,
      personalDifficulty: json['personal_difficulty'] as int?,
      qualityScore: (json['quality_score'] as num?)?.toDouble(),
      userNotes: json['user_notes'] as String?,
    );

Map<String, dynamic> _$SolutionFinishToJson(SolutionFinish instance) =>
    <String, dynamic>{
      'status': instance.status,
      'personal_difficulty': instance.personalDifficulty,
      'quality_score': instance.qualityScore,
      'user_notes': instance.userNotes,
    };

SessionModel _$SessionModelFromJson(Map<String, dynamic> json) => SessionModel(
      id: json['id'] as int,
      solutionId: json['solution_id'] as int,
      startTime: DateTime.parse(json['start_time'] as String),
      endTime: json['end_time'] == null
          ? null
          : DateTime.parse(json['end_time'] as String),
      durationMinutes: (json['duration_minutes'] as num?)?.toDouble(),
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$SessionModelToJson(SessionModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'solution_id': instance.solutionId,
      'start_time': instance.startTime.toIso8601String(),
      'end_time': instance.endTime?.toIso8601String(),
      'duration_minutes': instance.durationMinutes,
      'notes': instance.notes,
    };

SessionCreate _$SessionCreateFromJson(Map<String, dynamic> json) =>
    SessionCreate(
      solutionId: json['solution_id'] as int,
      startTime: DateTime.parse(json['start_time'] as String),
      endTime: DateTime.parse(json['end_time'] as String),
      duration: (json['duration'] as num).toDouble(),
    );

Map<String, dynamic> _$SessionCreateToJson(SessionCreate instance) =>
    <String, dynamic>{
      'solution_id': instance.solutionId,
      'start_time': instance.startTime.toIso8601String(),
      'end_time': instance.endTime.toIso8601String(),
      'duration': instance.duration,
    };
