import 'package:json_annotation/json_annotation.dart';
import 'problem.dart';

part 'solution.g.dart';

enum SolutionStatus { active, completed, abandoned }

@JsonSerializable()
class SolutionModel {
  final int id;
  final int problemId;
  final int userId;
  final SolutionStatus status;
  final int? personalDifficulty;
  final double? qualityScore;
  final double? xpEarned;
  final String? userNotes;
  final String? solutionImgPath;
  final String? solutionText;
  final double totalMinutes;
  final DateTime createdAt;
  final ProblemModel? problem;

  SolutionModel({
    required this.id,
    required this.problemId,
    required this.userId,
    required this.status,
    this.personalDifficulty,
    this.qualityScore,
    this.xpEarned,
    this.userNotes,
    this.solutionImgPath,
    this.solutionText,
    required this.totalMinutes,
    required this.createdAt,
    this.problem,
  });

  factory SolutionModel.fromJson(Map<String, dynamic> json) =>
      _$SolutionModelFromJson(json);

  Map<String, dynamic> toJson() => _$SolutionModelToJson(this);

  bool get hasText => solutionText != null && solutionText!.isNotEmpty;

  bool get hasImage =>
      solutionImgPath != null && solutionImgPath!.isNotEmpty;

  bool get isActive => status == SolutionStatus.active;

  bool get isCompleted => status == SolutionStatus.completed;

  String get statusText {
    switch (status) {
      case SolutionStatus.active:
        return 'В процессе';
      case SolutionStatus.completed:
        return 'Завершено';
      case SolutionStatus.abandoned:
        return 'Отложено';
    }
  }
}

@JsonSerializable()
class SolutionCreate {
  final int problemId;

  SolutionCreate({required this.problemId});

  Map<String, dynamic> toJson() => _$SolutionCreateToJson(this);
}

@JsonSerializable()
class SolutionFinish {
  final String status;
  final int? personalDifficulty;
  final double? qualityScore;
  final String? userNotes;

  SolutionFinish({
    required this.status,
    this.personalDifficulty,
    this.qualityScore,
    this.userNotes,
  });

  Map<String, dynamic> toJson() => _$SolutionFinishToJson(this);
}

@JsonSerializable()
class SessionModel {
  final int id;
  final int solutionId;
  final DateTime startTime;
  final DateTime? endTime;
  final double? durationMinutes;
  final String? notes;

  SessionModel({
    required this.id,
    required this.solutionId,
    required this.startTime,
    this.endTime,
    this.durationMinutes,
    this.notes,
  });

  factory SessionModel.fromJson(Map<String, dynamic> json) =>
      _$SessionModelFromJson(json);

  Map<String, dynamic> toJson() => _$SessionModelToJson(this);
}

@JsonSerializable()
class SessionCreate {
  final int solutionId;
  final DateTime startTime;
  final DateTime endTime;
  final double duration;

  SessionCreate({
    required this.solutionId,
    required this.startTime,
    required this.endTime,
    required this.duration,
  });

  Map<String, dynamic> toJson() => _$SessionCreateToJson(this);
}
