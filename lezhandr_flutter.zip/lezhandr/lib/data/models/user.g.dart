// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserModel _$UserModelFromJson(Map<String, dynamic> json) => UserModel(
      id: json['id'] as int,
      email: json['email'] as String?,
      username: json['username'] as String,
      isAnonymous: json['is_anonymous'] as bool,
      deviceId: json['device_id'] as String?,
      role: $enumDecode(_$UserRoleEnumMap, json['role']),
      createdAt: DateTime.parse(json['created_at'] as String),
    );

Map<String, dynamic> _$UserModelToJson(UserModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'email': instance.email,
      'username': instance.username,
      'is_anonymous': instance.isAnonymous,
      'device_id': instance.deviceId,
      'role': _$UserRoleEnumMap[instance.role],
      'created_at': instance.createdAt.toIso8601String(),
    };

const _$UserRoleEnumMap = {
  UserRole.admin: 'admin',
  UserRole.moderator: 'moderator',
  UserRole.user: 'user',
};

AuthResponse _$AuthResponseFromJson(Map<String, dynamic> json) => AuthResponse(
      accessToken: json['access_token'] as String,
      tokenType: json['token_type'] as String,
      user: json['user'] == null
          ? null
          : UserModel.fromJson(json['user'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$AuthResponseToJson(AuthResponse instance) =>
    <String, dynamic>{
      'access_token': instance.accessToken,
      'token_type': instance.tokenType,
      'user': instance.user?.toJson(),
    };

DeviceLoginRequest _$DeviceLoginRequestFromJson(Map<String, dynamic> json) =>
    DeviceLoginRequest(
      deviceId: json['device_id'] as String,
      secretKey: json['secret_key'] as String,
    );

Map<String, dynamic> _$DeviceLoginRequestToJson(DeviceLoginRequest instance) =>
    <String, dynamic>{
      'device_id': instance.deviceId,
      'secret_key': instance.secretKey,
    };

ConvertAccountRequest _$ConvertAccountRequestFromJson(
        Map<String, dynamic> json) =>
    ConvertAccountRequest(
      email: json['email'] as String,
      password: json['password'] as String,
      username: json['username'] as String?,
    );

Map<String, dynamic> _$ConvertAccountRequestToJson(
        ConvertAccountRequest instance) =>
    <String, dynamic>{
      'email': instance.email,
      'password': instance.password,
      'username': instance.username,
    };
