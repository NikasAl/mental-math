// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'billing.dart';

BillingBalanceModel _$BillingBalanceModelFromJson(Map<String, dynamic> json) =>
    BillingBalanceModel(
      balance: (json['balance'] as num).toDouble(),
      currency: json['currency'] as String,
      freeUsesLeft: json['free_uses_left'] as int,
      totalDailyLimit: json['total_daily_limit'] as int,
    );

Map<String, dynamic> _$BillingBalanceModelToJson(
        BillingBalanceModel instance) =>
    <String, dynamic>{
      'balance': instance.balance,
      'currency': instance.currency,
      'free_uses_left': instance.freeUsesLeft,
      'total_daily_limit': instance.totalDailyLimit,
    };

TopUpResponse _$TopUpResponseFromJson(Map<String, dynamic> json) =>
    TopUpResponse(
      paymentUrl: json['payment_url'] as String,
      paymentId: json['payment_id'] as String?,
    );

Map<String, dynamic> _$TopUpResponseToJson(TopUpResponse instance) =>
    <String, dynamic>{
      'payment_url': instance.paymentUrl,
      'payment_id': instance.paymentId,
    };
