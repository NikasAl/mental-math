# Лежандр — MindVector Mobile Client

Мобильный клиент для системы отслеживания прогресса в решении задач MindVector.

## Особенности

- 🧮 **Решение задач** — отслеживание времени, озарения, вопросы, подсказки
- 📚 **Библиотека** — источники и задачи с тегами
- 📊 **Статистика** — XP, стрик, активность
- 🤖 **AI Помощь** — подсказки от разных AI-персон (Кот Базис, Петрович, Лежандр)
- 📸 **Камера** — фотографирование условий и решений
- ✨ **Мотивация** — вдохновляющие тексты

## Технологии

- **Flutter 3.x** — UI Framework
- **Riverpod** — State Management
- **GoRouter** — Navigation
- **Dio** — HTTP Client
- **Flutter Secure Storage** — Token Storage

## Структура проекта

```
lib/
├── main.dart                    # Точка входа
├── app.dart                     # MaterialApp конфигурация
├── core/
│   ├── config/                  # Конфигурация (API URL и т.д.)
│   ├── theme/                   # Тема приложения
│   ├── router/                  # GoRouter навигация
│   └── motivation/              # Модуль мотивации
├── data/
│   ├── models/                  # DTO модели
│   ├── repositories/            # Репозитории
│   ├── services/                # API сервисы
│   └── storage/                 # Локальное хранилище
├── domain/
│   ├── entities/                # Business entities
│   └── usecases/                # Use cases
└── presentation/
    ├── providers/               # Riverpod providers
    ├── screens/                 # Экраны
    └── widgets/                 # Переиспользуемые виджеты
```

## Запуск

```bash
# Получить зависимости
flutter pub get

# Сгенерировать код (JSON serialization)
flutter pub run build_runner build

# Запустить на устройстве
flutter run
```

## Конфигурация

Отредактируйте `lib/core/config/app_config.dart` для изменения API URL:

```dart
static const String apiUrl = 'http://your-server:8000/api/v1';
```

## Экраны

| Экран | Маршрут | Описание |
|-------|---------|----------|
| Splash | `/` | Загрузка и авторизация |
| Home | `/main/home` | Главная страница |
| Library | `/main/library` | Библиотека задач |
| Statistics | `/main/statistics` | Статистика |
| Profile | `/main/profile` | Профиль пользователя |
| Problem Detail | `/problems/:id` | Детали задачи |
| Session | `/session/:id` | Интерактивная сессия |
| Camera | `/camera` | Захват фото |

## AI Персоны

| Персона | Модель | Цена |
|---------|--------|------|
| 🐱 Кот Базис | basis | Бесплатно (лимит) |
| 🧹 Петрович | petrovich | 2 ₽ |
| 🧐 Лежандр | legendre | 10 ₽ |

## Мотивация

Модуль мотивации показывает вдохновляющие тексты в разных контекстах:
- Утро/день/вечер — разное время суток
- Начало сессии — мотивация на решение
- Достижения — поздравления с里程碑ами
- Стрик — поддержка цепочки дней

## Разработка

### Требования

- Flutter SDK 3.x
- Dart 3.x
- Android Studio / VS Code

### Генерация кода

```bash
flutter pub run build_runner watch
```

### Линтер

```bash
flutter analyze
```

## Лицензия

MIT
